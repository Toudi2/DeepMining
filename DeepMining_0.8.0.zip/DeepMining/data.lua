require "config"

require "prototypes.items"
require "prototypes.recipes"
require "prototypes.entities"
require "prototypes.technologies"